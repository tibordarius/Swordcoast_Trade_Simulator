# Project Log

## 2026-09-29 — Project formalised

Created the [[Sword Coast Economic Simulator]] project workspace.

### Current concept

Build a live economic model of settlements and cities across the Sword Coast, including:

- resource origins;
- production;
- consumption;
- inventories;
- commodity prices;
- trading volume;
- physical trade routes;
- shipments;
- merchant organizations;
- exchange-style trading interfaces;
- eventual map overlay;
- campaign events that alter the economy.

### Working exchange concept

The first exchange is [[WDEX - Waterdeep Exchange]], inspired by live retail trading interfaces but backed by a physical economy.

### Architecture direction

Selected direction:

- Rust simulation core;
- React/TypeScript UI;
- PostgreSQL/PostGIS operational state;
- Timescale or equivalent time-series layer;
- DuckDB + Parquet analytics;
- MapLibre + deck.gl visualisation;
- PMTiles for static fantasy map data;
- deterministic replay and world branching.

### Key principle

Do not randomise prices directly. Random events change the world; the economy changes prices.

### Initial delivery plan

Two-week sprints beginning 29 September 2026. MVP target after the first 21 numbered sprints, with the engine, WDEX, six markets, map, analytics, DM controls and scenario branching included in the target scope.

## 2026-09-29 — Sprint 0 completed; Sprint 1 kernel started

- froze currency, quantity, cargo, time, reserve, price and provenance conventions;
- created machine-readable six-market / twenty-four-commodity seed data;
- added a seed validator and passed it;
- completed the hand-worked Athkatla-to-Waterdeep grain acceptance flow;
- created dependency-free Rust workspace for `sim-core` and `sim-cli`;
- implemented five-minute clock, stable ID wrappers, SplitMix64 and stable FNV-1a state hashing;
- created an independent Python determinism oracle;
- verified seed 12345 at 10,000 ticks produces state hash `4afdcd085b4f30b7` and repeated runs match;
- recorded current environment limitation: Rust toolchain unavailable and cannot be installed from rustup due DNS/network restriction.
