#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "reference"
WEB = ROOT / "code" / "web" / "wdex"
MAP = ROOT / "code" / "web" / "map"


def run(label, argv, cwd=ROOT):
    print(f"\n=== {label} ===")
    subprocess.run(argv, cwd=cwd, check=True)


def main():
    run("seed validation", [sys.executable, str(ROOT / "tools" / "validate_seed.py")])
    for script in [
        "sprint1_reference.py",
        "sprint2_grain.py",
        "sprint3_pricing.py",
        "sprint4_logistics.py",
        "sprint5_merchant.py",
        "sprint6_validation.py",
        "sprint7_persistence.py",
    ]:
        run(script, [sys.executable, str(REF / script)], REF)

    run("migration lint", [sys.executable, str(ROOT / "tools" / "lint_migrations.py")])

    node = shutil.which("node")
    if not node:
        raise SystemExit("node is required for Sprint 8–12 reference tests")
    run("Sprint 8 live protocol", [node, str(REF / "sprint8_live_protocol.mjs")], REF)
    run("Sprint 9 WDEX shell", [node, "--test", str(WEB / "market.test.mjs")], WEB)
    run("Sprint 10 trading", [node, "--test", str(WEB / "trading.test.mjs")], WEB)
    run("Sprint 11 multi-market", [node, "--test", str(WEB / "network.test.mjs")], WEB)
    run("Sprint 12 map calibration", [node, "--test", str(MAP / "calibration.test.mjs")], MAP)

    print("\nREFERENCE SUITE 0–12: PASS")

if __name__ == "__main__":
    main()
