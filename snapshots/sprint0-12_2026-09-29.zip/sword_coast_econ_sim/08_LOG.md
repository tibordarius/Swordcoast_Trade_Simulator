# Project Log

## 2026-09-29 — Project formalised

Created the [[Sword Coast Economic Simulator]] project workspace.

### Current concept

Build a live economic model of settlements and cities across the Sword Coast, including:

- resource origins;
- production;
- consumption;
- inventories;
- commodity prices;
- trading volume;
- physical trade routes;
- shipments;
- merchant organizations;
- exchange-style trading interfaces;
- eventual map overlay;
- campaign events that alter the economy.

### Working exchange concept

The first exchange is [[WDEX - Waterdeep Exchange]], inspired by live retail trading interfaces but backed by a physical economy.

### Architecture direction

Selected direction:

- Rust simulation core;
- React/TypeScript UI;
- PostgreSQL/PostGIS operational state;
- Timescale or equivalent time-series layer;
- DuckDB + Parquet analytics;
- MapLibre + deck.gl visualisation;
- PMTiles for static fantasy map data;
- deterministic replay and world branching.

### Key principle

Do not randomise prices directly. Random events change the world; the economy changes prices.

### Initial delivery plan

Two-week sprints beginning 29 September 2026. MVP target after the first 21 numbered sprints, with the engine, WDEX, six markets, map, analytics, DM controls and scenario branching included in the target scope.

## 2026-09-29 — Reference vertical slice reaches Sprint 6 validation

- implemented inventory reservation, shipment departure, ETA, derived progress and idempotent arrival;
- implemented market buy and sell slippage using fixed-point quantities;
- corrected an internal quantity-scale ambiguity before merchant integration;
- implemented merchant opportunity evaluation with capital, freight, route capacity, expected cargo loss and ROI threshold;
- static arbitrage test moves three 100,000 kg grain cargoes before the spread falls below the 5% ROI threshold;
- built an integrated 120-day ATHEX/WDEX grain benchmark;
- discovered that two concurrent 18-day shipments are insufficient to clear Waterdeep's structural deficit despite massive Athkatlan surplus;
- expanded logistics throughput from two to eight concurrent shipments and observed sharply lower unmet demand and average scarcity price;
- added a consolidated Python reference regression suite; all Sprint 1–6 reference tests pass.

## 2026-09-29 — Persistence, live protocol, WDEX and map foundation pulled forward

- added PostgreSQL 18/PostGIS 3.6 schema migrations for world, branches, provenance, settlements, commodities, markets, shipments, orders, event log and snapshots;
- added append-only protections for input events and trade executions;
- validated snapshot + event replay semantics with a standard-library persistence oracle;
- defined WebSocket/HTTP live-state contracts with monotonic sequence recovery and decimal-string encoding for 64-bit values;
- built a dependency-free WDEX market shell with exact BigInt formatting and order-preview slippage;
- implemented wallet, warehouse, limit-order reservation and warehouse-to-vessel physical cargo semantics;
- created a six-exchange grain network from CALEX to LUSEX and evaluate executable spreads after slippage, multi-hop freight, route risk and route capacity;
- recovered the existing campaign map configuration from `SwordCoastMap.md`: 6600×10200 px, center 3300/5100, scale 0.275 km/px;
- confirmed the actual referenced JPG is not in the uploaded campaign ZIP; settlement coordinates remain intentionally unguessed;
- built a local-only map calibration page that records Calimport, Athkatla, Baldur's Gate, Waterdeep, Neverwinter and Luskan directly from the user's existing map;
- consolidated all executable Sprint 0–12 checks into one regression suite.

