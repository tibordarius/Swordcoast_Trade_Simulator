# Project Log

## 2026-09-29 — Project formalised

Created the [[Sword Coast Economic Simulator]] project workspace.

### Current concept

Build a live economic model of settlements and cities across the Sword Coast, including:

- resource origins;
- production;
- consumption;
- inventories;
- commodity prices;
- trading volume;
- physical trade routes;
- shipments;
- merchant organizations;
- exchange-style trading interfaces;
- eventual map overlay;
- campaign events that alter the economy.

### Working exchange concept

The first exchange is [[WDEX - Waterdeep Exchange]], inspired by live retail trading interfaces but backed by a physical economy.

### Architecture direction

Selected direction:

- Rust simulation core;
- React/TypeScript UI;
- PostgreSQL/PostGIS operational state;
- Timescale or equivalent time-series layer;
- DuckDB + Parquet analytics;
- MapLibre + deck.gl visualisation;
- PMTiles for static fantasy map data;
- deterministic replay and world branching.

### Key principle

Do not randomise prices directly. Random events change the world; the economy changes prices.

### Initial delivery plan

Two-week sprints beginning 29 September 2026. MVP target after the first 21 numbered sprints, with the engine, WDEX, six markets, map, analytics, DM controls and scenario branching included in the target scope.

## 2026-09-29 — Reference vertical slice reaches Sprint 6 validation

- implemented inventory reservation, shipment departure, ETA, derived progress and idempotent arrival;
- implemented market buy and sell slippage using fixed-point quantities;
- corrected an internal quantity-scale ambiguity before merchant integration;
- implemented merchant opportunity evaluation with capital, freight, route capacity, expected cargo loss and ROI threshold;
- static arbitrage test moves three 100,000 kg grain cargoes before the spread falls below the 5% ROI threshold;
- built an integrated 120-day ATHEX/WDEX grain benchmark;
- discovered that two concurrent 18-day shipments are insufficient to clear Waterdeep's structural deficit despite massive Athkatlan surplus;
- expanded logistics throughput from two to eight concurrent shipments and observed sharply lower unmet demand and average scarcity price;
- added a consolidated Python reference regression suite; all Sprint 1–6 reference tests pass.
