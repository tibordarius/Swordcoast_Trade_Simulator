# Architecture & Product Decision Record

## ADR-001 — Simulation first, visualisation second

**Status:** Accepted  
**Date:** 2026-09-29

The project will prove a believable headless economy before investing heavily in map animation or exchange polish.

**Reason:** a beautiful trading interface over arbitrary/random prices would fail the core product idea.

---

## ADR-002 — Modular monolith for MVP

**Status:** Accepted  
**Date:** 2026-09-29

Start with one application/API and one authoritative simulation worker per world.

**Rejected for MVP:** microservices, Kafka, Kubernetes.

**Reason:** deterministic ordering and development speed matter more than horizontal service decomposition.

---

## ADR-003 — Rust simulation core

**Status:** Proposed/Preferred  
**Date:** 2026-09-29

Use Rust for the simulation engine and likely Axum for the server API.

**Reason:** deterministic performance, memory efficiency, parallelism and a future path to Rust/WASM.

**Validation required:** build a small benchmark spike before locking in.

---

## ADR-004 — PostgreSQL is durable world state, not the simulation loop

**Status:** Accepted  
**Date:** 2026-09-29

The hot numerical simulation executes in memory. PostgreSQL stores authoritative durable state, configuration and checkpoints.

---

## ADR-005 — PostGIS for geography

**Status:** Accepted  
**Date:** 2026-09-29

Settlements, regions, production zones and route geometry live in a spatial model compatible with PostGIS.

---

## ADR-006 — DuckDB + Parquet for historical analytics

**Status:** Accepted direction  
**Date:** 2026-09-29

Recent data remains operational/time-series data. Long historical data moves to Parquet and is queried with DuckDB.

DuckDB-Wasm will be benchmarked for browser-side historical exploration.

---

## ADR-007 — Prices are emergent

**Status:** Accepted  
**Date:** 2026-09-29

Randomness may alter harvests, risks, weather, production and events. It must not directly assign arbitrary market prices.

Prices derive from economic state and market mechanics.

---

## ADR-008 — One authoritative writer per world

**Status:** Accepted  
**Date:** 2026-09-29

Parallel calculation is allowed, but one ordered commit controls authoritative world transitions.

---

## ADR-009 — Fixed-point values for authoritative quantities

**Status:** Preferred  
**Date:** 2026-09-29

Currency and core commodity quantities should use integer/fixed-point representation where feasible.

---

## ADR-010 — Provenance is part of the data model

**Status:** Accepted  
**Date:** 2026-09-29

Data must distinguish Forgotten Realms canon, Whale Campaign canon, inference and simulation-generated state.

---

## ADR-011 — Do not simulate individual civilians

**Status:** Accepted  
**Date:** 2026-09-29

Population demand is aggregated into sectors. Significant merchant organizations may be simulated individually because their behaviour matters to gameplay.

---

## ADR-012 — Ship positions are derived

**Status:** Accepted  
**Date:** 2026-09-29

Persist route, departure, ETA and state. Derive current map position client-side or server-side when queried. Do not write continuous position ticks to the database.

---

## ADR-013 — Five-minute authoritative base tick

**Status:** Accepted  
**Date:** 2026-09-29

The authoritative simulation clock advances in five-minute ticks. Subsystems are multi-rate/event-driven and do not execute every base tick.

---

## ADR-014 — Commodity-specific base units

**Status:** Accepted  
**Date:** 2026-09-29

There is no universal trade unit. Each commodity has a semantic unit such as kg, litre, cubic metre, bolt or item-equivalent, represented using integer fixed-point sub-units. Cargo mass and volume are modeled separately.

---

## ADR-015 — Deterministic RNG algorithm begins dependency-free

**Status:** Accepted for kernel v0  
**Date:** 2026-09-29

Use a fully specified SplitMix64 implementation for the first deterministic kernel and derive named subsystem streams from stable identifiers. This avoids relying on external RNG crate implementation stability for replay compatibility.

---

## ADR-016 — AI remains outside the deterministic boundary

**Status:** Accepted  
**Date:** 2026-09-29

LLMs may translate DM prose into proposed structured events, extract lore or explain deterministic outputs. Only approved structured events enter the authoritative event log. LLM calls never execute inside the simulation tick loop.

---

## ADR-017 — Monetary precision is milli-copper, superseding cp-only storage

**Status:** Accepted  
**Date:** 2026-09-29

Sprint 3 demonstrated that wholesale unit quotations require sub-copper precision (`1.75 cp/kg` is a normal case). Authoritative monetary values and quotes therefore use integer **milli-copper pieces (mcp)** where `1 cp = 1,000 mcp`.

This supersedes the cp-only internal precision stated in the first Sprint 0 draft. No floating-point authoritative prices are allowed.

---

## ADR-018 — Pricing v0 is causal and piecewise-integer

**Status:** Accepted as calibration baseline  
**Date:** 2026-09-29

The first pricing function uses integer basis-point components for reserve pressure, unmet demand, effective incoming supply and risk. The function is intentionally simple, monotonic and explainable. Its elasticity parameters are calibration data, not permanent economic truth.
