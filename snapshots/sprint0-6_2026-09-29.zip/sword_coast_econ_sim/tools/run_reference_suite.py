#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "reference"
SCRIPTS = [
    "sprint1_reference.py",
    "sprint2_grain.py",
    "sprint3_pricing.py",
    "sprint4_logistics.py",
    "sprint5_merchant.py",
    "sprint6_validation.py",
]

def main():
    for script in SCRIPTS:
        print(f"\n=== {script} ===")
        subprocess.run([sys.executable, str(REF / script)], cwd=REF, check=True)
    print("\nREFERENCE SUITE: PASS")

if __name__ == "__main__":
    main()
