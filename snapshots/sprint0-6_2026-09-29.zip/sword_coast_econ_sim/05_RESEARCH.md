# Research

## Research Principle

Separate **what the setting explicitly says** from **what the simulation needs to infer**.

Every imported fact should be labelled:

- **FR Canon** — explicitly supported by a Forgotten Realms source.
- **Campaign Canon** — established in the Whale Campaign.
- **Inference** — economically/geographically reasoned from supported facts.
- **Simulation Generated** — emergent current-world state.

## User-Supplied Reference Set

- Reddit: `https://www.reddit.com/r/DnDBehindTheScreen/comments/1i1c2o4/trade_and_economics_in_the_sword_coast_region_of/`
- Forgotten Realms Wiki, Mercantile Company: `https://forgottenrealms.fandom.com/wiki/Mercantile_company`
- LinkedIn commodity trading article: `https://www.linkedin.com/pulse/commodity-trading-across-faer%C3%BBn-how-waterdeep-company-murray-fife-3yube/`
- SJ Games forum thread: `https://forums.sjgames.com/showthread.php?t=42351`
- The Alexandrian, The Trade Way: `https://thealexandrian.net/wordpress/44297/roleplaying-games/forgotten-realms-the-trade-way`
- Facebook discussion: `https://www.facebook.com/groups/392678574938393/posts/976157276590517/`

## Source Priority

1. Forgotten Realms books/sourcebooks and the project's converted FR corpus.
2. Explicit Whale Campaign canon.
3. Lore wikis where the underlying source citation can be checked.
4. High-quality route/economic reconstruction such as The Alexandrian.
5. Community historical-economic reasoning.
6. Unsourced extrapolation only when needed, clearly labelled.

## Current Economic Hypotheses

### Northern resource gradient

The northern Sword Coast should tend to export natural resources such as timber, metals, hides/furs and selected crafts while importing food, manufactured goods and luxuries.

### Waterdeep as processor/redistributor

[[Waterdeep]] should consume large quantities of raw materials and food while producing/refining a broad range of finished goods. It is more useful as a liquid hub than as simply the market with the highest prices.

### Southern agricultural/luxury flows

[[Amn]], [[Tethyr]] and [[Calimshan]] are candidates for substantial food, wine, textiles, luxury and exotic-goods flows toward northern cities, depending on the underlying source material.

### Trade routes are choices

Merchants should choose among sea, road, river and clandestine routes based on time, cost, capacity, tariffs and risk rather than pure geographic distance.

### Whale products matter economically

The campaign already makes whaling and whale politics important. [[Whale Oil]], [[Ambergris]], bone/baleen-equivalent materials, and related substitutes should form meaningful commodity chains rather than decorative lore.

## Research Work Packages

### R01 — Canonical settlement import/export extraction

For each settlement/region:

- imports;
- exports;
- industries;
- agricultural products;
- mines/resources;
- population estimate and period;
- ports/roads/rivers;
- political/tariff constraints;
- source/page.

### R02 — Trade route graph

Extract and reconcile:

- named roads;
- river navigability;
- sea lanes;
- passes;
- seasonal closures;
- dangerous regions;
- customs/tolls;
- pirate areas.

### R03 — Commodity ontology

Determine a practical hierarchy:

`raw resource -> processed material -> finished commodity -> luxury/specialist commodity`

Avoid excessive granularity until it produces gameplay value.

### R04 — Historical pricing analogues

Use historical maritime/Hanseatic/East India trade only as an economic calibration tool, not as lore canon.

Research:

- freight share of cargo value;
- warehouse costs;
- loss rates;
- bulk vs luxury margins;
- seasonal grain pricing;
- route capacity;
- insurance/risk premiums.

### R05 — Market microstructure

Research what elements actually improve gameplay:

- spot market;
- bid/ask spread;
- market depth;
- slippage;
- warehouse receipt;
- forward delivery contract;
- charter contract;
- index construction.

Avoid derivatives until the physical market works.

## Technical Research Queue

- Benchmark Rust simulation representations: AoS vs SoA.
- Benchmark PostgreSQL partitions vs Timescale for expected tick volume.
- Benchmark Arrow IPC vs MessagePack/JSON for live market deltas.
- Benchmark DuckDB-Wasm with 100 MB, 500 MB and 1 GB representative Parquet history.
- Test PMTiles with custom fantasy coordinates/map raster/vector sources.
- Compare pgRouting against precomputed/in-memory Rust route matrices.
- Investigate whether H3 is appropriate after Toril georeferencing; do not force Earth assumptions onto the map.

## Open Research Questions

- What Forgotten Realms year/edition is the campaign economy anchored to?
- What is the economic scale of magic in normal trade versus rare specialist trade?
- What population estimates should be canonical for simulation purposes?
- How much food reserve should large cities maintain?
- How quickly does price information travel without magical communication?
- Which factions have magical communications that materially improve information latency?
- How common are teleportation circles for commercial freight versus people/information?
- How should intelligent undersea societies interact with surface logistics?
